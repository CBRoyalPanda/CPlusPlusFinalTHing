#include <iostream>
#include <string>

using namespace std;

//This was meant to store character names so they could be reused later
class CharacterNames
{ 
    // Access specifier 
    public: 
  
    // Data Members 
    string PlayerName; 
  
    // Member Functions() 
    void printname() 
    { 
		cout << "Hello " << PlayerName << endl;
    } 
}; 

void Begin();
void McDonalds();
void Drugstore();
void StartGame();

int PlayerCash = 0;
string PlName;

int main()
{
	
	//Uses an object to get the players name
	//This is super unnesisary, but I did it this way so I could show that I know how classes work
	cout << "What is your name?" << endl;
	cin >> PlName;
	
	CharacterNames obj1;

	obj1.PlayerName = PlName;

	obj1.printname();

	Begin();
	
	int choice1 = 0;
	
	StartGame();

	
	
	return 0;
}

void Begin()
{
	//Exposition
	cout << "You just woke up after a long night of tossing and turning." << endl;
	cout << "You are currently starving, but you need something to get rid of your killer headache." << endl;
	cout << "What will you do?" << endl;
}

void McDonalds()
{
	cout << "Make your way through surprisingly thick traffic and get to McDonalds." << endl;
	cout << "'May I take your order?' an unenthused employee mutters under their breath." << endl;
	cout << endl << "What should I order?" << endl;
	int choice2A = 0;

	//While loop prevents the player from choosing an invalid option;
	while (choice2A != 1 && choice2A != 2 && choice2A != 3)
	{
		//Decision 2A
		cout << "1) Big Mac" << endl;
		cout << "2) Salad" << endl;
		cout << "3) Money" << endl;
		
		//Player input
		cin >> choice2A;

		if (choice2A == 1)
		{
			//Bad ending
			cout << "You take a bite into the lifeless dry burger." << endl;
			cout << "Just through the taste of the burger alone, you can tell that you were just given diabetes." << endl;
			cout << "The diabetes is the final straw for your deplorable immune system." << endl;
			cout << "As your life fades from your body you think, 'Was it worth it?'" << endl;
			cout << endl << "No... It was not..." << endl;
			cout << endl << "Bad End" << endl;
			
		}

		else if (choice2A == 2)
		{
			//Restart to the beginning
			cout << "You choose this thinking it is a heathly option." << endl;
			cout << "However, the large amount of salt in the salad dehydrates you." << endl;
			cout << "The dehydration makes your headache significantly worse." << endl;
			cout << "The pain causes you to pass out..." << endl;
			StartGame();
		}

		else if (choice2A == 3)
		{
			//Player gets money and goes to the drugstore
			cout << "The cashier recoiled in fear, thinking they were getting robbed." << endl;
			cout << "They hand you everything that was in the cash register." << endl;
			cout << "You got 50 dollars!" << endl;
			PlayerCash += 50;
			cout << "They also gave you a fish fillet on the house!" << endl;

			cout << endl << "Now that your hunger is taken care of, you decide to go to the drug store to fix your headache." << endl;
			Drugstore();
		}

		else
		{
			cout << endl << choice2A << " is not a valid option, please try again.\n" << endl;
		}
	}
}

void Drugstore()
{
	//Making your way to the drug store
	cout << "You drive your way to the drugstore." << endl;
	cout << "As you walk through the isles you find some pain relief medication." << endl;
	cout << "There is the name brand 'Tylonol', and then the store brand 'Dielonol'" << endl;
	cout << "Which will you pick?" << endl;
	int choice2B = 0;

	while (choice2B != 1 && choice2B != 2)
	{
		//Decision 2B
		cout << endl << "1) Tylonol (50$)" << endl;
		cout << "2) Dielonol (Free)" << endl;

		//Player input
		cin >> choice2B;

		if (choice2B == 1 && PlayerCash >= 50)
		{
			//Good Ending
			cout << "You have sucesfully cured your headache!" << endl;
			cout << "You have now succeeded at life." << endl;
			cout << "Good job." << endl;
			cout << endl << "Good End" << endl;

		}

		else if (choice2B == 1 && PlayerCash < 50)
		{
			cout << endl << "You only have " << PlayerCash << "dollars, try again" << endl;
		}

		else if (choice2B == 2)
		{
			//Bad Ending
			cout << "You instantly regret your life choices as you take the pill." << endl;
			cout << "You curse store brand medication under your breath as you seize on the floor" << endl;
			cout << endl << "Bad End" << endl;
		}

		else
		{
			//Invalid input check
			cout << endl << choice2B << " is not a valid option, please try again.\n" << endl;
		}
	}
}

void StartGame()
{
	int choice1 = 0;

	//While loop prevents the player from choosing an option that is not 1 or 2;
	while (choice1 != 1 && choice1 != 2)
	{
		//Decision 1
		cout << "1) Go to McDonalds" << endl;
		cout << "2) Go to the Drugstore" << endl;
		//Player input
		cin >> choice1;

		if (choice1 == 1)
		{
			//Goes to mcD
			McDonalds();
		}

		else if (choice1 == 2)
		{
			//Gets Drugs
			Drugstore();
		}

		else
		{
			cout << endl << choice1 << " is not a valid option, please try again.\n" << endl;
		}
	}
}